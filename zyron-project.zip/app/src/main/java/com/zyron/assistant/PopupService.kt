package com.zyron.assistant

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class PopupService : Service() {
    private lateinit var windowManager: WindowManager
    private var popup: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (popup == null) showPopup()
        return START_NOT_STICKY
    }

    private fun showPopup() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(Color.rgb(8, 28, 58))
        }
        val heading = TextView(this).apply {
            text = "✦ ZYRON"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(70, 220, 255))
        }
        val status = TextView(this).apply {
            text = "Hello! AI connection not set up yet."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 12)
        }
        val listen = Button(this).apply {
            text = "Listen (demo)"
            setOnClickListener {
                status.text = "Voice recognition is not connected in this prototype."
            }
        }
        val close = Button(this).apply {
            text = "Close popup"
            setOnClickListener { stopSelf() }
        }
        panel.addView(heading)
        panel.addView(status)
        panel.addView(listen)
        panel.addView(close)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 150
        }
        windowManager.addView(panel, params)
        popup = panel
    }

    override fun onDestroy() {
        popup?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        popup = null
        super.onDestroy()
    }
}
