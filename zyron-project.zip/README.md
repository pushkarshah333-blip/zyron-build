# ZYRON AI — Android Studio Starter

This is a starter project, not a finished/installable APK. It provides a floating ZYRON popup prototype and a basic Android app shell.

## What it includes
- Kotlin Android app structure
- Permission flow for displaying a floating popup over other apps
- Microphone permission request
- A simple popup UI with Listen / Close controls
- A clear placeholder where a secure AI backend can be connected

## Important limits
- Android does **not** provide unrestricted access to every phone feature or every other app.
- ZYRON can only use features that Android exposes and that the user grants permission for.
- Always-on hotword detection while the screen is off is not guaranteed; Android battery/background restrictions and device-specific behavior can stop it.
- This starter does not yet contain a working AI backend, real wake-word engine, or an installable APK.
- Do not put a private AI API key directly in an Android app. Connect to a small backend that stores the key securely.

## Open it
1. Install Android Studio.
2. Choose **Open** and select this project folder.
3. Let Gradle sync.
4. Run on your Android phone with USB debugging enabled.
5. Grant microphone permission when prompted. Tap **Enable floating popup** and allow **Display over other apps** in Android settings.

## Next development steps
1. Add a backend endpoint for AI chat.
2. Add a proper foreground microphone service and persistent notification.
3. Add a dedicated wake-word engine and test screen-off behavior on the target phone.
4. Add user-confirmed actions for calling, messages, settings, and other supported Android intents.


## Build an APK using only your Android phone (cloud build)
This ZIP includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`.
Upload the extracted project files to a GitHub repository, then open the repository's
**Actions** tab and run **Build ZYRON APK**. When the run succeeds, open the run,
scroll to **Artifacts**, and download `ZYRON-debug-APK`. Extract that downloaded ZIP
to get `app-debug.apk`, then tap the APK on your phone to install it.

This cloud build requires a GitHub account and internet access. GitHub's interface may
vary on mobile; if needed, use your browser's **Desktop site** option. Only install APKs
you built yourself and trust. This is a debug prototype, not a finished assistant.
