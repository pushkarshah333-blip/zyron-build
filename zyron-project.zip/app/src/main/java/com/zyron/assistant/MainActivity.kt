package com.zyron.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 15, 35)
        window.navigationBarColor = Color.rgb(5, 15, 35)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(5, 15, 35))
        }
        val title = TextView(this).apply {
            text = "ZYRON AI"
            textSize = 32f
            setTextColor(Color.rgb(60, 210, 255))
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Your voice assistant prototype\n\nEnable the floating popup to try the interface."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 28)
        }
        val popupButton = Button(this).apply {
            text = "Enable floating popup"
            setOnClickListener { enablePopup() }
        }
        val permissionButton = Button(this).apply {
            text = "Request microphone permission"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 23 &&
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 20)
                } else {
                    description.text = "Microphone permission is already granted."
                }
            }
        }
        layout.addView(title)
        layout.addView(description)
        layout.addView(popupButton)
        layout.addView(permissionButton)
        setContentView(layout)
    }

    private fun enablePopup() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            startActivity(intent)
            return
        }
        startService(Intent(this, PopupService::class.java))
    }
}
